import { showSection } from "../utils/utils.js";

const section = document.getElementById("homePage");

export function showHome() {
   showSection(section)
}